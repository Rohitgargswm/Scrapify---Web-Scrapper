from flask import Flask, jsonify
from flask_cors import CORS
import subprocess
import json
import os

app = Flask(__name__)
CORS(app)  # Enables CORS for frontend requests

# Function to scrape job data and return it
def scrape_jobs():
    try:
        subprocess.run(["python", "JobScrapperscript.py"], check=True)
        with open("job_listings.json", "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        return {"error": f"Job scraping failed: {str(e)}"}

# Function to scrape news data and return it
def scrape_news():
    try:
        subprocess.run(["python", "News scrapper.py"], check=True)
        latest_news_file = sorted([f for f in os.listdir() if f.startswith("news_")], reverse=True)[0]
        with open(latest_news_file, "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        return {"error": f"News scraping failed: {str(e)}"}

# API to return the latest job listings
@app.route("/jobs", methods=["GET"])
def get_jobs():
    return jsonify(scrape_jobs())

# API to return the latest news
@app.route("/news", methods=["GET"])
def get_news():
    return jsonify(scrape_news())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
