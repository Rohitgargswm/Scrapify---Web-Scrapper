#!/usr/bin/env python
# coding: utf-8

# In[2]:


import requests
import json
import datetime

# Your API key
API_KEY = "5afedd6441a64a2599fa39d045617773"
NEWS_URL = "https://newsapi.org/v2/top-headlines"

# List of available categories
categories = ["business", "entertainment", "health", "science", "sports", "technology", "general"]

# Get user input for category
category = input(f"Enter news category {categories}: ").strip().lower()

# Validate category
if category not in categories:
    print("Invalid category! Defaulting to 'general'.")
    category = "general"

# Define request parameters
params = {
    "country": "us",
    "category": category,
    "apiKey": API_KEY
}

def fetch_news():
    """Fetches top headlines using NewsAPI"""
    try:
        response = requests.get(NEWS_URL, params=params)
        response.raise_for_status()  # Raise error for bad responses
        data = response.json()

        if data["status"] != "ok":
            print("Error fetching news:", data.get("message", "Unknown error"))
            return None

        return data["articles"][:10]  # Get top 10 articles

    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return None

def save_to_json(articles):
    """Saves news articles to a JSON file with a timestamp"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"news_{category}_{timestamp}.json"

    news_data = {
        "timestamp": timestamp,
        "category": category,
        "country": "us",
        "articles": [{"title": article["title"], "source": article["source"]["name"], "published_at": article["publishedAt"]}
                     for article in articles]
    }

    with open(filename, "w", encoding="utf-8") as file:
        json.dump(news_data, file, indent=4, ensure_ascii=False)

    print(f"✅ News saved to {filename} ({len(articles)} articles)")

# Run the script
articles = fetch_news()
if articles:
    save_to_json(articles)
else:
    print("❌ No news available. Please check your API key or internet connection.")


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




