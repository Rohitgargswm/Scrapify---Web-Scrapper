document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM fully loaded.");

    const jobsButton = document.getElementById("fetchJobs");
    const newsButton = document.getElementById("fetchNews");

    if (jobsButton) {
        jobsButton.addEventListener("click", () => fetchData("jobs", "jobs-listings"));
    } else {
        console.warn("⚠ fetchJobs button not found!");
    }

    if (newsButton) {
        newsButton.addEventListener("click", () => fetchData("news", "news-listings"));
    } else {
        console.warn("⚠ fetchNews button not found!");
    }
});

// Function to fetch data and display it
async function fetchData(category, containerId) {
    try {
        const response = await fetch(`http://127.0.0.1:5000/${category}`);
        const data = await response.json();

        let content = "<ul>";
        if (category === "jobs" && Array.isArray(data)) {
            data.forEach(job => {
                content += `<li><strong>${job.title}</strong> - ${job.company} (${job.location})</li>`;
            });
        } else if (category === "news" && data.articles) {
            data.articles.forEach(article => {
                content += `<li><a href="${article.url}" target="_blank">${article.title}</a> - ${article.source}</li>`;
            });
        } else {
            content = "<p>No data available.</p>";
        }
        content += "</ul>";

        document.getElementById(containerId).innerHTML = content;
    } catch (error) {
        console.error(`❌ Error fetching ${category} data:`, error);
        document.getElementById(containerId).innerHTML = "<p>Error loading data.</p>";
    }
}
