// const express = require("express");
// const axios = require("axios");
// const cheerio = require("cheerio");
// const cors = require("cors");
// const fs = require("fs");

// const app = express();
// app.use(express.json());
// app.use(cors());

// const PORT = 5000;

// /* 1️⃣ SCRAPE LATEST NEWS */
// app.get("/fetch-news", async (req, res) => {
//     try {
//         const response = await axios.get("https://www.bbc.com/news");
//         const $ = cheerio.load(response.data);
//         let news = [];

//         $(".gs-c-promo-heading").each((i, element) => {
//             if (i < 10) {
//                 const title = $(element).text().trim();
//                 const link = $(element).attr("href");
//                 news.push({ title, link: `https://www.bbc.com${link}` });
//             }
//         });

//         fs.writeFileSync("news.json", JSON.stringify(news, null, 4));
//         res.json({ success: true, news });
//     } catch (error) {
//         console.error("Error scraping news:", error);
//         res.status(500).json({ success: false, message: "Failed to fetch news." });
//     }
// });

// /* 2️⃣ FETCH JOBS FROM JOOBLE API */
// const JOOBLE_API_KEY = "YOUR_JOOBLE_API_KEY"; // Replace with your actual key
// app.post("/fetch-jobs", async (req, res) => {
//     const { keywords, location } = req.body;
//     try {
//         const response = await axios.post(`https://jooble.org/api/${JOOBLE_API_KEY}`, {
//             keywords, location, page: 1
//         }, { headers: { "Content-Type": "application/json" } });

//         const jobs = response.data.jobs || [];
//         fs.writeFileSync("jobs.json", JSON.stringify(jobs, null, 4));
//         res.json({ success: true, jobs });
//     } catch (error) {
//         console.error("Error fetching jobs:", error);
//         res.status(500).json({ success: false, message: "Failed to fetch jobs." });
//     }
// });

// /* 3️⃣ SCRAPE STOCK MARKET DATA */
// app.get("/fetch-stocks", async (req, res) => {
//     try {
//         const response = await axios.get("https://finance.yahoo.com/");
//         const $ = cheerio.load(response.data);
//         let stocks = [];

//         $(".simpTblRow").each((i, element) => {
//             if (i < 10) {
//                 const name = $(element).find("td:nth-child(1)").text().trim();
//                 const price = $(element).find("td:nth-child(2)").text().trim();
//                 const change = $(element).find("td:nth-child(3)").text().trim();
//                 stocks.push({ name, price, change });
//             }
//         });

//         fs.writeFileSync("stocks.json", JSON.stringify(stocks, null, 4));
//         res.json({ success: true, stocks });
//     } catch (error) {
//         console.error("Error scraping stocks:", error);
//         res.status(500).json({ success: false, message: "Failed to fetch stocks." });
//     }
// });

// /* HOME ROUTE */
// app.get("/", (req, res) => {
//     res.send("Welcome to the ScraperX API! Use /fetch-news, /fetch-jobs, or /fetch-stocks.");
// });

// /* Start Server */
// app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());

// Fix Favicon.ico issue
app.get("/favicon.ico", (req, res) => res.status(204));

// API Endpoints
app.get("/api/jobs", async (req, res) => {
    try {
        const response = await axios.get("http://127.0.0.1:5000/jobs");
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Error fetching jobs" });
    }
});

app.get("/api/news", async (req, res) => {
    try {
        const response = await axios.get("http://127.0.0.1:5000/news");
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Error fetching news" });
    }
});

app.listen(3000, () => console.log("✅ Server running on port 3000"));
