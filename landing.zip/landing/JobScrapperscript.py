#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
import json
import os

def fetch_jobs(api_key, keywords, location, num_jobs=10):
    url = f"https://jooble.org/api/{api_key}"
    headers = {"Content-Type": "application/json"}
    payload = {"keywords": keywords, "location": location, "page": 1}
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        jobs = response.json().get("jobs", [])[:num_jobs]
        return jobs
    else:
        print(f"Error: {response.status_code}, {response.text}")
        return []

def save_jobs_to_json(jobs, filename="job_listings.json"):
    try:
        script_dir = os.getcwd()
        file_path = os.path.join(script_dir, filename)
        
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(jobs, f, indent=4)
        print(f"Jobs saved to {file_path}")
    except OSError as e:
        print(f"File save error: {e}")

def main():
    api_key = "785a7218-c393-4ee8-af4f-2b1fc903c2fe"
    keywords = input("Enter the job field you are looking for: ")
    location = input("Enter the job location: ")
    
    jobs = fetch_jobs(api_key, keywords, location, num_jobs=20)
    
    if jobs:
        save_jobs_to_json(jobs)
    else:
        print("No jobs found.")

if __name__ == "__main__":
    main()


# In[ ]:





# In[ ]:





# In[ ]:




