import sys
import json
import requests
from bs4 import BeautifulSoup

def scrape_stocks():
    url = " https://query1.finance.yahoo.com/v8/finance/chart/AAPL"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")

    stocks = []
    for stock in soup.select(".stock-item"):
        name = stock.select_one(".stock-name").text
        price = stock.select_one(".stock-price").text
        stocks.append({"name": name, "price": price})

    return stocks

if __name__ == "__main__":
    category = sys.argv[1]
    if category == "stocks":
        print(json.dumps(scrape_stocks()))
